<!DOCTYPE html>
<html>
	<head>
		<title>ISTE-341 Lab 1</title>
	</head>
	<body>
		<h1>Question 1</h1>
		<?php
			echo "<p>Hello, World! from php</p>";
		?>
	</body>
</html>
